Welcome to the C# program for my website.

When launching the program, it is important to note you need an account currently registered on the website.
After logging in, it will ask you if you want to use a previous config.
This refers to fileConfig.txt found in the same directory and is generated after a successful run of the program.

When selecting a directory, make sure you include the whole path to the directory. ex. C:\Users\%USERNAME%\Desktop

